KGxhbWJkYTogcHJpbnQoIldvcmtpbmcgVGVzdCEiKSkoKQ== # base64
# (lambda: print("Working Test!"))()

#!!madebyrootle$